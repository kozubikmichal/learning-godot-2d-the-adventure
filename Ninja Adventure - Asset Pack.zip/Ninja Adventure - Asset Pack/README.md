# Ninja Adventure Asset Pack

Assets created by:
[Pixel-boy](https://pixel-boy.itch.io/)
[AAA](https://www.instagram.com/challenger.aaa/?hl=fr)

# License

They are released under the Creative Commons Zero (CC0) license.

You can use any and all of the assets found in this package in your own games,
even commercial ones. Attribution is not required but appreciated.

# Placing one of these links somewhere would be awesome :)
Patreon: https://www.patreon.com/pixelarchipel 
Itchio Page: https://pixel-boy.itch.io/
Pack Page: https://pixel-boy.itch.io/ninja-adventure-asset-pack

